document.addEventListener('DOMContentLoaded', () => {
    const textElements = document.querySelectorAll('h1, h2, h3, p, span, a');

    function animateOnScroll() {
        textElements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const elementBottom = element.getBoundingClientRect().bottom;
            const isVisible = (elementTop >= 0) && (elementBottom <= window.innerHeight);

            if (isVisible) {
                if (!element.dataset.animated) {
                    element.style.opacity = 0;
                    let opacity = 0;
                    const interval = setInterval(() => {
                        opacity += 0.05;
                        element.style.opacity = opacity;
                        if (opacity >= 1) {
                            clearInterval(interval);
                            element.dataset.animated = true;
                        }
                    }, 50); // Ajustez la vitesse de l'animation ici (plus petit = plus rapide)
                }
            } else {
                element.style.opacity = element.dataset.animated ? 1 : 0;
                delete element.dataset.animated;
            }
        });
    }

    window.addEventListener('scroll', animateOnScroll);
    window.addEventListener('resize', animateOnScroll);
    animateOnScroll(); // Pour vérifier au chargement de la page
});
